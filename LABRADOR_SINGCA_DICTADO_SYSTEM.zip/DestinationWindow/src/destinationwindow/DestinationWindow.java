package destinationwindow;

import javax.swing.*;
import java.awt.*;
import javax.swing.table.TableColumn;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DestinationWindow extends JFrame {

    public DestinationWindow() {
        setTitle("Destination Information");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String[] columnNames = {"DESTINATION", "PRICE"};
        String[][] data = {
            {"Dinalupihan", "Php 65.00"},
            {"Hermosa", "Php 50.00"},
            {"Orani", "Php 35.00"},
            {"Samal", "Php 25.00"},
            {"Abucay", "Php 20.00"},
            {"Pilar", "Php 30.00"},
            {"Orion", "Php 40.00"},
            {"Limay", "Php 50.00"},
            {"Mariveles", "Php 60.00"},
            {"Bagac", "Php 60.00"},
            {"Morong", "Php 55.00"}
        };

        JTable table = new JTable(data, columnNames);
        table.setEnabled(false);
        table.setFont(new Font("Arial", Font.BOLD, 18));

        JScrollPane scrollPane = new JScrollPane(table);
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Set a margin around the table
        int margin = 15;
        int smargin = 0;
        int tmargin = 30;
        scrollPane.setBorder(BorderFactory.createEmptyBorder(tmargin, margin, smargin, margin));

        // Adjust column width
        TableColumn column = null;
        for (int i = 0; i < columnNames.length; i++) {
            column = table.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(200); // Set preferred width for the first column
            } else {
                column.setPreferredWidth(100); // Set preferred width for other columns
            }
        }

        // Adjust row height
        table.setRowHeight(30); // Set the desired row height (in pixels)

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 20)); // Adjust the vertical gap as needed
        JButton buyTicketButton = new JButton("Buy Ticket");
        buyTicketButton.setFont(new Font("Arial", Font.BOLD, 18));

        Dimension buttonSize = new Dimension(360, 40);
        buyTicketButton.setPreferredSize(buttonSize);
        buyTicketButton.setMinimumSize(buttonSize);
        buyTicketButton.setMaximumSize(buttonSize);

        buttonPanel.add(Box.createVerticalStrut(10)); // Add a vertical gap
        buttonPanel.add(buyTicketButton);

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        int width = 400;  // Desired width
        int height = 500;  // Set a larger height
        setPreferredSize(new Dimension(width, height));

        pack();
        setLocationRelativeTo(null); // Center the window on the screen

        buyTicketButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open a new window for ticket selection
                TicketSelectionWindow ticketSelectionWindow = new TicketSelectionWindow(data, DestinationWindow.this);
                ticketSelectionWindow.setVisible(true);
                setVisible(false); // Hide the current window
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DestinationWindow window = new DestinationWindow();
            window.setVisible(true);
        });
    }
}

class TicketSelectionWindow extends JFrame {

    private DestinationWindow destinationWindow; // Reference to the DestinationWindow

    public TicketSelectionWindow(String[][] destinations, DestinationWindow destinationWindow) {
        this.destinationWindow = destinationWindow; // Store the reference to the DestinationWindow

        JPanel contentPane = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Choose a Destination");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        int topMargin = 15; // Adjust the margin as needed
        titleLabel.setBorder(BorderFactory.createEmptyBorder(topMargin, 0, 0, 0));
        contentPane.add(titleLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(0, 3, 10, 10)); // 3 columns, with spacing between buttons

        for (String[] destination : destinations) {
            String placeName = destination[0];
            String placePrice = destination[1];
            JButton placeButton = new JButton(placeName);
            placeButton.setFont(new Font("Arial", Font.BOLD, 16));

            // Change the size of the button by modifying the preferred size
            Dimension buttonSize = new Dimension(120, 40); // Adjust the size as needed
            placeButton.setPreferredSize(buttonSize);
            placeButton.setMinimumSize(buttonSize);
            placeButton.setMaximumSize(buttonSize);

            buttonPanel.add(placeButton);

            placeButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Perform action when a destination button is clicked
                    TicketTypeWindow ticketTypeWindow = new TicketTypeWindow(placeName, placePrice);
                    ticketTypeWindow.setVisible(true);
                    setVisible(false); // Hide the current window
                }
            });
        }

        JButton backButton = new JButton("<"); // Button to go back to DestinationWindow
        backButton.setFont(new Font("Arial", Font.BOLD, 10));

        // Change the size of the button by modifying the preferred size
        Dimension backButtonSize = new Dimension(25, 40); // Adjust the size as needed
        backButton.setPreferredSize(backButtonSize);
        backButton.setMinimumSize(backButtonSize);
        backButton.setMaximumSize(backButtonSize);

        JPanel backButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        backButtonPanel.add(backButton);
        int bottomMargin = 20; // Adjust the margin as needed
        backButtonPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, bottomMargin, 0));
        contentPane.add(backButtonPanel, BorderLayout.WEST);

        int width = 400; // Desired width
        int height = (width * 4) / 3; // Calculate height for a 4:3 ratio
        setPreferredSize(new Dimension(width, height));

        setContentPane(contentPane);
        pack();
        setLocationRelativeTo(null); // Center the window on the screen

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the TicketSelectionWindow
                destinationWindow.setVisible(true); // Show the DestinationWindow
            }
        });

        contentPane.add(buttonPanel, BorderLayout.CENTER);

        // Set a margin around the table
        int margin = 0;
        int rmargin = 15;
        int smargin = 20;
        int tmargin = 5;
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(tmargin, margin, smargin, rmargin));

        setContentPane(contentPane);
        pack();
        setLocationRelativeTo(null); // Center the window on the screen
    }
}

class TicketTypeWindow extends JFrame {

    private String destination;
    private String price;

    public TicketTypeWindow(String destination, String price) {
        this.destination = destination;
        this.price = price;

        setTitle("Ticket Type");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel contentPane = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Choose a Ticket type");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setHorizontalAlignment(SwingConstants.LEFT);
        int topMargin = 15; // Adjust the margin as needed
        titleLabel.setBorder(BorderFactory.createEmptyBorder(topMargin, 30, 0, 0));
        contentPane.add(titleLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(3, 1, 15, 15));

        JButton normalButton = new JButton("Normal");
        normalButton.setFont(new Font("Arial", Font.BOLD, 20));
        normalButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Perform action when the normal button is clicked
                ConfirmPurchaseWindow confirmPurchaseWindow = new ConfirmPurchaseWindow(destination, price, "NORMAL");
                confirmPurchaseWindow.setVisible(true);
                dispose(); // Close the ticket type window
            }
        });

        JButton studentButton = new JButton("Student");
        studentButton.setFont(new Font("Arial", Font.BOLD, 20));
        studentButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Perform action when the student button is clicked
                ConfirmPurchaseWindow confirmPurchaseWindow = new ConfirmPurchaseWindow(destination, price, "STUDENT");
                confirmPurchaseWindow.setVisible(true);
                dispose(); // Close the ticket type window
            }
        });

        JButton seniorButton = new JButton("Senior");
        seniorButton.setFont(new Font("Arial", Font.BOLD, 20));
        seniorButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Perform action when the senior button is clicked
                ConfirmPurchaseWindow confirmPurchaseWindow = new ConfirmPurchaseWindow(destination, price, "SENIOR");
                confirmPurchaseWindow.setVisible(true);
                dispose(); // Close the ticket type window
            }
        });

        JButton backButton = new JButton("<"); // Button to go back to DestinationWindow
        backButton.setFont(new Font("Arial", Font.BOLD, 10));

        // Change the size of the button by modifying the preferred size
        Dimension backButtonSize = new Dimension(25, 40); // Adjust the size as needed
        backButton.setPreferredSize(backButtonSize);
        backButton.setMinimumSize(backButtonSize);
        backButton.setMaximumSize(backButtonSize);

        JPanel backButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        backButtonPanel.add(backButton);
        int bottomMargin = 20; // Adjust the margin as needed
        backButtonPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, bottomMargin, 0));
        contentPane.add(backButtonPanel, BorderLayout.WEST);

        int width = 400; // Desired width
        int height = (width * 4) / 3; // Calculate height for a 4:3 ratio
        setPreferredSize(new Dimension(width, height));

        setContentPane(contentPane);
        pack();
        setLocationRelativeTo(null); // Center the window on the screen

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DestinationWindow destinationWindow = new DestinationWindow();
                destinationWindow.setVisible(true);
                dispose(); // Close the receipt window
            }
        });

        contentPane.add(buttonPanel, BorderLayout.CENTER);

        buttonPanel.add(normalButton);
        buttonPanel.add(studentButton);
        buttonPanel.add(seniorButton);

        int margin = 0;
        int rmargin = 15;
        int smargin = 20;
        int tmargin = 5;
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(tmargin, margin, smargin, rmargin));

        getContentPane().add(buttonPanel, BorderLayout.CENTER);
        pack();
        setLocationRelativeTo(null); // Center the window on the screen
    }
}

class ConfirmPurchaseWindow extends JFrame {

    private String destination;
    private String price;
    private String ticketType;

    public ConfirmPurchaseWindow(String destination, String price, String ticketType) {
        this.destination = destination;
        this.price = price;
        this.ticketType = ticketType;

        setTitle("Confirm Purchase");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel destinationLabel3 = new JLabel("");
        JLabel destinationLabel0 = new JLabel("Confirm purchase for ");
        JLabel destinationLabel = new JLabel(" Destination: ");
        JLabel destinationLabel1 = new JLabel("   " + destination);
        JLabel ticketTypeLabel = new JLabel(" Ticket type: ");
        JLabel ticketTypeLabel1 = new JLabel("   " + ticketType);
        JLabel ticketTypeLabel0 = new JLabel(" ");
        JLabel ticketTypeLabel2 = new JLabel(" ");
        destinationLabel0.setFont(new Font("Monospaced", Font.BOLD, 20));
        destinationLabel.setFont(new Font("Monospaced", Font.BOLD, 15));
        destinationLabel1.setFont(new Font("Monospaced", Font.BOLD, 30));
        ticketTypeLabel.setFont(new Font("Monospaced", Font.BOLD, 15));
        ticketTypeLabel1.setFont(new Font("Monospaced", Font.BOLD, 30));
        ticketTypeLabel0.setFont(new Font("Monospaced", Font.BOLD, 15));

        // Set the layout manager to BorderLayout
        getContentPane().setLayout(new BorderLayout());

        // Create a panel for the labels
        JPanel detailsPanel = new JPanel(new GridLayout(8, 1, 0, 0));
        detailsPanel.add(destinationLabel3);
        detailsPanel.add(destinationLabel0);
        detailsPanel.add(destinationLabel);
        detailsPanel.add(destinationLabel1);
        detailsPanel.add(ticketTypeLabel);
        detailsPanel.add(ticketTypeLabel1);
        detailsPanel.add(ticketTypeLabel0);
        detailsPanel.add(ticketTypeLabel2);
        // Add the panel to the center of the frame
        getContentPane().add(detailsPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton yesButton = new JButton("Yes");
        yesButton.setFont(new Font("Arial", Font.BOLD, 18));

        Dimension buttonSize = new Dimension(360, 40);
        yesButton.setPreferredSize(buttonSize);
        yesButton.setMinimumSize(buttonSize);
        yesButton.setMaximumSize(buttonSize);

        yesButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open a new window for the receipt
                ReceiptWindow receiptWindow = new ReceiptWindow(destination, price, ticketType);
                receiptWindow.setVisible(true);
                dispose(); // Close the confirmation window
            }
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setFont(new Font("Arial", Font.BOLD, 18));

        Dimension buttonSize2 = new Dimension(360, 40);
        cancelButton.setPreferredSize(buttonSize2);
        cancelButton.setMinimumSize(buttonSize2);
        cancelButton.setMaximumSize(buttonSize2);

        cancelButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DestinationWindow destinationWindow = new DestinationWindow();
                destinationWindow.setVisible(true);
                dispose(); // Close the confirmation window
            }
        });

        buttonPanel.add(yesButton);
        buttonPanel.add(cancelButton);

        int margin = 40;
        int rmargin = 40;
        int smargin = 120;
        int tmargin = 120;
        int Amargin = 20;
        int bmargin = 60;
        destinationLabel0.setBorder(BorderFactory.createEmptyBorder(tmargin, margin, smargin, rmargin));
        destinationLabel.setBorder(BorderFactory.createEmptyBorder(tmargin, margin, smargin, rmargin));
        destinationLabel1.setBorder(BorderFactory.createEmptyBorder(tmargin, margin, smargin, rmargin));
        ticketTypeLabel.setBorder(BorderFactory.createEmptyBorder(tmargin, margin, smargin, rmargin));
        ticketTypeLabel1.setBorder(BorderFactory.createEmptyBorder(tmargin, margin, smargin, rmargin));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(Amargin, Amargin, bmargin, Amargin));

        int width = 400;  // Desired width
        int height = (width * 4) / 3;  // Calculate height for a 4:3 ratio
        setPreferredSize(new Dimension(width, height));

        getContentPane().add(buttonPanel, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(null); // Center the window on the screen
    }

    public void showNextWindow() {
        // Open a new window for the receipt
        ReceiptWindow receiptWindow = new ReceiptWindow(destination, price, ticketType);
        receiptWindow.setVisible(true);
        dispose(); // Close the confirmation window
    }
}

class ReceiptWindow extends JFrame {

    private String destination;
    private String price;
    private String ticketType;

    public ReceiptWindow(String destination, String price, String ticketType) {
        this.destination = destination;
        this.price = price;
        this.ticketType = ticketType;

        setTitle("Receipt");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        double fare = Double.parseDouble(price.substring(4)); // Extract the fare amount without the "Php " prefix

        if (ticketType.equals("STUDENT") || ticketType.equals("SENIOR")) {
            fare *= 0.8; // Apply 20% discount for student or senior ticket
        }

        String farePrice = "Php " + fare;

        JTextArea receiptTextArea = new JTextArea();
        receiptTextArea.setEditable(false);
        receiptTextArea.setFont(new Font("Monospaced", Font.PLAIN, 18));

        receiptTextArea.append("*******************************\n");
        receiptTextArea.append("**       TICKET DETAILS      **\n");
        receiptTextArea.append("*******************************\n");
        receiptTextArea.append("                                 \n");
        receiptTextArea.append("   Destination: " + destination + "\n");
        receiptTextArea.append("                                 \n");
        receiptTextArea.append("   Ticket type: " + ticketType + "\n");
        receiptTextArea.append("                                 \n");
        receiptTextArea.append("   Fare Price: " + farePrice + "\n");
        receiptTextArea.append("                                 \n");
        receiptTextArea.append("  Thank you for your purchase!  \n");
        receiptTextArea.append("                                 \n");
        receiptTextArea.append("*******************************\n");

        int margin = 10;
        int rmargin = 10;
        int smargin = 20;
        int tmargin = 20;
        receiptTextArea.setBorder(BorderFactory.createEmptyBorder(tmargin, margin, smargin, rmargin));

        int width = 400;  // Desired width
        int height = (width * 4) / 3;  // Calculate height for a 4:3 ratio
        setPreferredSize(new Dimension(width, height));

        JScrollPane scrollPane = new JScrollPane(receiptTextArea);

        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 20)); // Adjust the vertical gap as needed
        JButton backButton = new JButton("Go back to main menu");
        backButton.setFont(new Font("Arial", Font.BOLD, 16));

        Dimension buttonSize = new Dimension(360, 40);
        backButton.setPreferredSize(buttonSize);
        backButton.setMinimumSize(buttonSize);
        backButton.setMaximumSize(buttonSize);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DestinationWindow destinationWindow = new DestinationWindow();
                destinationWindow.setVisible(true);
                dispose(); // Close the receipt window
            }
        });

        buttonPanel.add(Box.createVerticalStrut(10)); // Add a vertical gap
        buttonPanel.add(backButton);
        getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(null); // Center the window on the screen
    }
}
